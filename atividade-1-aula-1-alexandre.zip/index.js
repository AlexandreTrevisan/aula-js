const numPrincipal = 10;
let num = 1;
if (num >= numPrincipal){
  console.log ("o numero e maior que 10");
}