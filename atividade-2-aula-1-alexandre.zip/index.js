const numPrimario = 5;
let numSecundario = 5;
if (numSecundario == numPrimario){
  console.log("os numeros sao iguais");
} 