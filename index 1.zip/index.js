const MEDIA = 60
let notaEstudante = 70;
if (notaEstudante >=MEDIA) {
  console.log ("aprovado")
} else {
  console.log ("reprovado")
}