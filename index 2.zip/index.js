let nota = "D";
switch(nota) {
  case "A":
    console.log("aluno aprovado com A.");
  break;
  case "B":
    console.log("aluno aprovado com B.");
  break;
  case "C":
    console.log("aluno aprovado com C.");
  break;
  default:
    console.log("aluno reprovado.");
}