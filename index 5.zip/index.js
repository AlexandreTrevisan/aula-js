let name = "Alexandre Trevisan";
function meuNome(nome){
  return nome;
}
console.log(meuNome(name));