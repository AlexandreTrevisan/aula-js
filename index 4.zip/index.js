let i = 0;
while (i <= 10) {
  let text = " the number is " + i;
  console.log(text);
  i++;
}