const num = 5;
if (Number.isInteger(num/2)) {
  console.log("o numero e par");
} else {
  console.log("o numero e impar");
}